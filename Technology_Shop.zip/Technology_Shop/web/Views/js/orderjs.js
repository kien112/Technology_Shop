/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

function show(index){
//    if(index===1){
//        document.getElementById('table1').style.display = "none";
//        document.getElementById('table2').style.display = "block";
//    }else{
//        document.getElementById('table1').style.display = "block";
//        document.getElementById('table2').style.display = "none";
//    }
    document.getElementById("a").style.display = "none";
}
