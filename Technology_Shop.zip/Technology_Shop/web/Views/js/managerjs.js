/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


function show(index){
//    if(index==1)
//        document.getElementById('delete').style.display = 'block';
//    else if(index == 2)
//        document.getElementById('edit').style.display = 'block';
}

function hide(index){
//    if(index==1)
//        document.getElementById('delete').style.display = 'none';
//    else if(index == 2)
//        document.getElementById('edit').style.display = 'none';
}